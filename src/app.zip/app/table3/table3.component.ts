import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'table3',
  templateUrl: './table3.component.html',
  styleUrls: ['./table3.component.css']
})
export class Table3Component implements OnInit {

  columnDefs = [
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SO Number', field: 'soNum' ,width:158,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fiscal Year', field: 'fiscalYear' ,width:158,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Source Trans Date', field: 'sourceTransactionDate' ,width:158,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;SalesRep Number', field: 'salesrepNumber' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Territory Name', field: 'territoryName' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Territory Type', field: 'territoryType' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Part Number', field: 'partNumber' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Service Type', field: 'serviceType' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;RO Flag', field: 'roFlag' ,width:158 ,cellStyle: {'text-align':'center'}},
    
    { headerName: 'Commission Status', field: 'commissionStatus' ,width:158 ,cellStyle: {'text-align':'center'}},
    
    
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;REV', field: 'rev' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Exception Type', field: '' ,width:158 ,cellStyle: {'text-align':'center'}},
    
    

    ];

  progName=localStorage.getItem("ProgName")
  rowData: any;


  constructor(private http: HttpClient) {
  }

  ngOnInit() {
    this.rowData = this.http.get('http://localhost:8080/peo/programData/fetchValidData?programName='+this.progName+'&status=EXCEPTION');
  }
}
