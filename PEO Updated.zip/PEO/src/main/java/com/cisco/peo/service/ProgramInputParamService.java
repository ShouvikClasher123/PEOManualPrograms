package com.cisco.peo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cisco.peo.bean.InputParam;
import com.cisco.peo.bean.Program;
import com.cisco.peo.bean.ProgramDetail;
import com.cisco.peo.repository.ProgramInputParamRepository;

@Service
public class ProgramInputParamService {
	
	@Autowired
	private ProgramInputParamRepository programInputParamRepository;

	public InputParam fetchInputParam(String programName) {
		return programInputParamRepository.fetchInputParam(programName);
	}
	
public InputParam saveInputParam(InputParam inputParam) {
		
		InputParam inputParams = new InputParam();
		
		inputParams.setProgramName(inputParam.getProgramName());
		inputParams.setFromPid(inputParam.getFromPid());
		inputParams.setSoNum(inputParam.getSoNum());
		inputParams.setTerritoryType(inputParam.getTerritoryType());
		inputParams.setTransGroupCode(inputParam.getTransGroupCode());
		inputParams.setToPid(inputParam.getToPid());
		return programInputParamRepository.save(inputParams);
		
	}
	
	public void editInputParam(InputParam inputParam) {
		
		programInputParamRepository.editInputParam(inputParam.getFromPid(), inputParam.getProgramName(),inputParam.getSoNum(), inputParam.getTerritoryType(),inputParam.getTransGroupCode(), inputParam.getToPid());
		
	}

	
}
