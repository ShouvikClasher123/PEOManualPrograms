package com.cisco.peo.bean;

public class ProgramDetail {
	
	private String year;
	private String terrType;
	private String fet;
	private String uniqueName;
	private String type;
	@Override
	public String toString() {
		return "ProgramDetail [year=" + year + ", terrType=" + terrType + ", fet=" + fet + ", uniqueName=" + uniqueName
				+ ", type=" + type + ", category=" + category + "]";
	}
	private String category;
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getTerrType() {
		return terrType;
	}
	public void setTerrType(String terrType) {
		this.terrType = terrType;
	}
	public String getFet() {
		return fet;
	}
	public void setFet(String fet) {
		this.fet = fet;
	}
	public String getUniqueName() {
		return uniqueName;
	}
	public void setUniqueName(String uniqueName) {
		this.uniqueName = uniqueName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

}
