import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { GetProgramNamesService } from '../get-program-names.service';

@Component({
  selector: 'program-creation',
  templateUrl: './program-creation.component.html',
  styleUrls: ['./program-creation.component.css']
})
export class ProgramCreationComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private getProgramNamesService: GetProgramNamesService) { }

  createNewForm: FormGroup;
  editForm: FormGroup;
  inputParamForm: FormGroup;
  selectProgramForm: FormGroup;

  public page1Flag: boolean = true;
  public page2Flag: boolean = false;
  public showFlag: boolean = false;
  public showFlag2: boolean = false;
  public showFlag3: boolean = false;
  public sec2Flag: boolean = false;
  public sec2_NextFlag: boolean = false;
  public sec2_EditFlag: boolean = false;
  public sec3Flag: boolean = false;
  private names: any;
  private programTypes: any;
  private programCategories: any;
  public editData: any;
  public inputParamsData:any;
  public selectedProgram: string = '';

  //event handler for the select element's change event
  selectChangeHandler(event: any) {
    //update the ui
    this.selectedProgram = event.target.value;
    localStorage.setItem("ProgName", this.selectedProgram);
    console.log(this.selectedProgram);
    this.getProgramNamesService.getEditData(this.selectedProgram).subscribe(data => { this.editData = data; }, err => console.error(err), () => console.log('done loading edit data'));
    this.getProgramNamesService.getInputParams(this.selectedProgram).subscribe(data => { this.inputParamsData = data; console.log(data)}, err => console.error(err), () => console.log('done loading categories'));
    // this.inputParamForm.controls["fromPid"].setValue(this.inputParamsData.fromPid);
  }

    //event handler for the select element's change event
    // selectChangeHandler2(event: any) {
    //   //update the ui
    //   this.selectedProgram = event.target.value;
    //   localStorage.setItem("ProgName", this.selectedProgram);
    //   this.getProgramNamesService.getInputParams(this.selectedProgram).subscribe(data => { this.inputParamsData = data; console.log(data)}, err => console.error(err), () => console.log('done loading categories'));
      
    // }



  ngOnInit() {

    var self = this;
    this.editData = {};
    this.inputParamsData = {};

    if(localStorage.getItem("page1")!="null" && localStorage.getItem("page2")!="null"){
      this.page1Flag=false;
      this.page2Flag=true;
      this.getProgramNamesService.getInputParams(this.selectedProgram).subscribe(data => { this.inputParamsData = data; console.log(data)}, err => console.error(err), () => console.log('done loading categories'));
      
    }
    this.selectedProgram=localStorage.getItem("ProgName");
    this.getProgramNamesService.getNames().subscribe(data => { self.names = data; }, err => console.error(err), () => console.log('done loading names'));
    this.getProgramNamesService.getProgramType().subscribe(data => { self.programTypes = data; }, err => console.error(err), () => console.log('done loading types'));
    this.getProgramNamesService.getProgramCategory().subscribe(data => { self.programCategories = data; }, err => console.error(err), () => console.log('done loading categories'));
    

    this.createNewForm = this.formBuilder.group({

      year: [null, [Validators.required]],
      terrType: [null, [Validators.required]],
      fet: [null, [Validators.required]],
      uniqueName: [null, [Validators.required]],
      type: [null, [Validators.required]],
      category: [null, [Validators.required]],

    });



    this.editForm = this.formBuilder.group({
      year: [self.editData.year, [Validators.required]],
      terrType: [null, [Validators.required]],
      fet: [null, [Validators.required]],
      uniqueName: [null, [Validators.required]],
      type: [self.editData.type, [Validators.required]],
      category: [self.editData.category, [Validators.required]],

    });

    this.inputParamForm = this.formBuilder.group({
      programName: [null, ],
      fromPid: [null, [Validators.required]],
      toPid: [null, [Validators.required]],
      soNum: [null, [Validators.required]],
      territoryType: [null, [Validators.required]],
      transGroupCode: [null, [Validators.required]],

    });

    this.selectProgramForm = this.formBuilder.group({
      programName: [null, [Validators.required]]
    })
  }

  showFormData() {
    var self = this;
    this.getProgramNamesService.saveData(this.createNewForm.value);
    setTimeout(() => {
      this.getProgramNamesService.getNames().subscribe(data => { self.names = data; }, err => console.error(err), () => console.log('done reloading names'));
      this.displayMsg();
    }, 500);
  }

  showFormData2() {
    this.getProgramNamesService.postEditData(this.editForm.value);
    this.showFlag2 = true;
    setTimeout(() => {    //<<<---    using ()=> syntax
      this.showFlag2 = false;
    }, 4000);
  }

  showFormData3(){
    this.inputParamForm.controls["programName"].setValue(this.selectedProgram);
    // alert(JSON.stringify(this.inputParamForm.value));
    console.log("params:",this.inputParamsData);
    if(this.inputParamsData == null){
      this.getProgramNamesService.saveInputParams(this.inputParamForm.value);
    }
    else{
    this.getProgramNamesService.updateInputParams(this.inputParamForm.value);
    this.showFlag3 = true;
    setTimeout(() => {    //<<<---    using ()=> syntax
      this.showFlag3 = false;
    }, 4000);
    }

  }




  displayMsg() {
    this.showFlag = true;
    setTimeout(() => {    //<<<---    using ()=> syntax
      this.showFlag = false;
    }, 4000);
  }
}
