import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PEOManualPrograms';
  ngOnInit(): void {
    localStorage.setItem("page1",null);
    localStorage.setItem("page2",null);
    
  }
  
}
