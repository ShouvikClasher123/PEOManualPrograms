import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { CustomCell1Component } from '../custom-cell1/custom-cell1.component';
import { CustomCell2Component } from '../custom-cell2/custom-cell2.component';

@Component({
  selector: 'table2',
  templateUrl: './table2.component.html',
  styleUrls: ['./table2.component.css']
})
export class Table2Component implements OnInit {
  columnDefs = [
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SO Number', field: 'soNum' ,width:158,cellStyle: {'text-align':'center'}},
    { headerName: 'Transaction Number', field: 'transNumber' ,width:158,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;Bonus Earned Date', field: 'bookDateBonusEarnedDate' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bonus Paid Date', field: 'trxDateBonusPaidDate' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From Pid', field: 'fromPid' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To Pid', field: 'toPid' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From Paymt Amt', field: 'fromSalesValuePymntAmt' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To Paymt Amt', field: 'toSalesValuePymntAmt' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Split Percentage', field: 'splitPercentage' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;Trans Group Code', field: 'transGroupCode' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;SalesRep Number', field: 'salesrepNumber' ,width:158 ,
    cellStyle: function (params) {
      if (params.value == '' || params.value== null) {
        return { 'background-color': 'rgba(255,0,0,0.3)', 'border-radius': '2px' ,'text-align':'center'};
      }
    }},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;Share Segment 1', field: 'shareSegment1' ,width:158 ,
    cellStyle: function (params) {
      if (params.value == '' || params.value== null) {
        return { 'background-color': 'rgba(255,0,0,0.3)', 'border-radius': '2px' ,'text-align':'center'};
      }
    }},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Territory Type', field: 'territoryType' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hierarchy Name', field: 'hierarchyName' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Roll Up Flag', field: 'rollUpFlag' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Service Type', field: 'serviceType' ,width:158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Currency Code', field: 'currencyCode' ,width:158 ,cellStyle: {'text-align':'center'}},
    
    

    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Status', field: 'status', width: 158 ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Error Reason', field: 'errorMessage', width: 158, cellRendererFramework: CustomCell1Component ,cellStyle: {'text-align':'center'}},
    { headerName: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Validate', field: 'validateLink', width: 158, cellRendererFramework: CustomCell2Component ,cellStyle: {'text-align':'center'}}
  ];


  progName=localStorage.getItem("ProgName")
  rowData: any;


  constructor(private http: HttpClient) {
  }

  ngOnInit() {
    this.rowData = this.http.get('http://localhost:8080/peo/programData/fetchValidData?programName='+this.progName+'&status=ERROR');
  }
}
