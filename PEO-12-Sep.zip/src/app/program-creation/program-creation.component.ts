import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { GetProgramNamesService } from '../get-program-names.service';

@Component({
  selector: 'program-creation',
  templateUrl: './program-creation.component.html',
  styleUrls: ['./program-creation.component.css']
})
export class ProgramCreationComponent implements OnInit {

  constructor(private formBuilder:FormBuilder, private getProgramNamesService:GetProgramNamesService) { }

  form1: FormGroup;

  public showFlag:boolean=false;
  public sec2Flag:boolean=false;
  public sec2_1Flag:boolean=false;
  public sec3Flag:boolean=false;
  private names:any;
  private programTypes:any;
  private programCategories:any;

  public selectedProgram: string = '';

  //event handler for the select element's change event
  selectChangeHandler (event: any) {
    //update the ui
    this.selectedProgram = event.target.value;
    localStorage.setItem("ProgName", this.selectedProgram);
  }

  

  ngOnInit() {

    var self=this;
    this.getProgramNamesService.getNames().subscribe(data => { self.names = data; },err => console.error(err),() => console.log('done loading names'));
    this.getProgramNamesService.getProgramType().subscribe(data => { self.programTypes = data; },err => console.error(err),() => console.log('done loading names'));
    this.getProgramNamesService.getProgramCategory().subscribe(data => { self.programCategories = data; },err => console.error(err),() => console.log('done loading names'));
        

    this.form1 = this.formBuilder.group({
      year: [null, [Validators.required]],
      terrType: [null, [Validators.required]],
      fet: [null, [Validators.required]],
      uniqueName: [null, [Validators.required]],
      type: [null, [Validators.required]],
      category: [null, [Validators.required]],
      
    });
  }

  showFormData(){
    alert(JSON.stringify(this.form1.value));
    this.getProgramNamesService.saveData(this.form1.value);
    this.displayMsg();
  }

  displayMsg(){
    this.showFlag=true;
    setTimeout(()=>{    //<<<---    using ()=> syntax
      this.showFlag = false;
 }, 4000);
  }
}
