package com.cisco.peo.utils;
public final class Constant {
	private Constant(){
	}

	public static final String PROP_CONNECTION_FILE = "connection.properties";
	
}
